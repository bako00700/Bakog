import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Mic, i as Radio, o as Magnet, r as Square, s as ChevronDown, t as Waves } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DnLEoPDm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FERROUS_PHASE = 42;
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function classify(dI, dQ, threshold) {
	const mag = Math.hypot(dI, dQ);
	const phaseDeg = Math.atan2(dQ, dI) * 180 / Math.PI;
	const absPhase = Math.min(90, Math.abs(phaseDeg));
	const vdi = clamp(Math.round(99 * (1 - absPhase / 90)), 0, 99);
	if (mag < threshold) return {
		kind: "empty",
		phaseDeg,
		mag,
		vdi: 0,
		confidence: 1,
		label: "فراغ",
		detail: "لا يوجد هدف فوق العتبة — عاير في الهواء ثم قرّب المعدن من الملف."
	};
	const confidence = clamp((mag - threshold) / (threshold * 2.4), .28, .98);
	if (mag < threshold * 1.35) return {
		kind: "weak",
		phaseDeg,
		mag,
		vdi,
		confidence,
		label: "إشارة ضعيفة",
		detail: "اقترب أكثر أو ارفع الحساسية. الطور غير كافٍ للتمييز بعد."
	};
	if (absPhase >= FERROUS_PHASE) return {
		kind: "ferrous",
		phaseDeg,
		mag,
		vdi,
		confidence,
		label: "معدن حديدي",
		detail: "مكوّن تفاعلي (X) غالب — نفاذية مغناطيسية مرتفعة، نمط الحديد والفولاذ."
	};
	return {
		kind: "nonferrous",
		phaseDeg,
		mag,
		vdi,
		confidence,
		label: "غير حديدي",
		detail: "مكوّن مقاومي (R) غالب — تيارات دوامية من النحاس أو الألومنيوم أو الذهب."
	};
}
/** Physically-motivated R/X signatures at ~4 kHz VLF. */
var METAL_SAMPLES = [
	{
		id: "iron-nail",
		name: "مسمار حديد",
		latin: "Fe",
		kind: "ferrous",
		r: .16,
		x: .78,
		note: "نفاذية عالية، تيارات دوامية ضعيفة نسبياً."
	},
	{
		id: "steel",
		name: "فولاذ",
		latin: "Steel",
		kind: "ferrous",
		r: .26,
		x: .66,
		note: "حديدي مخلوط — طور مرتفع مع بعض الفقد."
	},
	{
		id: "ferrite",
		name: "فريت",
		latin: "Ferrite",
		kind: "ferrous",
		r: .05,
		x: .9,
		note: "شبه محض تفاعلي — مرجع نفاذية."
	},
	{
		id: "copper",
		name: "نحاس",
		latin: "Cu",
		kind: "nonferrous",
		r: .84,
		x: .16,
		note: "موصلية عالية، طور منخفض."
	},
	{
		id: "aluminum",
		name: "ألومنيوم",
		latin: "Al",
		kind: "nonferrous",
		r: .72,
		x: .22,
		note: "تيارات دوامية قوية على 4 كيلوهرتز."
	},
	{
		id: "gold",
		name: "ذهب",
		latin: "Au",
		kind: "nonferrous",
		r: .5,
		x: .3,
		note: "موصلية متوسطة — يقع بين الألومنيوم والحديد على محور التمييز."
	},
	{
		id: "silver",
		name: "فضة",
		latin: "Ag",
		kind: "nonferrous",
		r: .9,
		x: .12,
		note: "أعلى موصليات شائعة — أقرب إلى محور R."
	}
];
function sampleById(id) {
	if (!id) return void 0;
	return METAL_SAMPLES.find((s) => s.id === id);
}
var emptyClass = {
	kind: "empty",
	phaseDeg: 0,
	mag: 0,
	vdi: 0,
	confidence: 1,
	label: "فراغ",
	detail: "شغّل الإرسال ثم عاير في الهواء."
};
var useDetectorStore = create()((set) => ({
	mode: "sim",
	running: true,
	transmitting: false,
	calibrating: false,
	calibrated: true,
	error: null,
	sampleId: "iron-nail",
	distance: .22,
	reading: emptyClass,
	history: [],
	autoDemo: true,
	settings: {
		frequency: 4e3,
		txGain: .22,
		threshold: .08,
		beep: true
	},
	setMode: (mode) => set({
		mode,
		error: null,
		calibrated: mode === "sim"
	}),
	setRunning: (running) => set({ running }),
	setTransmitting: (transmitting) => set({ transmitting }),
	setCalibrating: (calibrating) => set({ calibrating }),
	setCalibrated: (calibrated) => set({ calibrated }),
	setError: (error) => set({ error }),
	setSampleId: (sampleId) => set({
		sampleId,
		autoDemo: false
	}),
	setDistance: (distance) => set({
		distance,
		autoDemo: false
	}),
	setReading: (reading) => set({ reading }),
	pushDetection: (d) => set((s) => ({ history: [d, ...s.history].slice(0, 16) })),
	clearHistory: () => set({ history: [] }),
	patchSettings: (partial) => set((s) => ({ settings: {
		...s.settings,
		...partial
	} })),
	setAutoDemo: (autoDemo) => set({ autoDemo })
}));
var WAVE = 512;
var TRAIL = 140;
var TWO_PI = Math.PI * 2;
function makeWave() {
	return new Float32Array(WAVE);
}
function emptySnapshot() {
	return {
		t: 0,
		i: 0,
		q: 0,
		mag: 0,
		phaseDeg: 0,
		vdi: 0,
		kind: "empty",
		confidence: 1,
		label: "فراغ",
		detail: "",
		running: false,
		transmitting: false,
		approach: 0,
		tx: makeWave(),
		rx: makeWave(),
		trail: []
	};
}
function noise() {
	return (Math.random() - .5) * 2;
}
var DetectorEngine = class {
	snapshot = emptySnapshot();
	raf = 0;
	startedAt = 0;
	approach = .72;
	rawI = 0;
	rawQ = 0;
	iCal = 0;
	qCal = 0;
	calFrames = 0;
	calI = 0;
	calQ = 0;
	lastKind = "empty";
	lastDetectAt = 0;
	demoIndex = 0;
	demoUntil = 0;
	audio = null;
	worklet = null;
	mic = null;
	stream = null;
	txAnalyser = null;
	rxAnalyser = null;
	beepOsc = null;
	beepGain = null;
	calCount = 40;
	lastUi = 0;
	workletReady = false;
	start() {
		if (this.raf) return;
		this.startedAt = performance.now();
		this.demoUntil = this.startedAt + 4200;
		const loop = (now) => {
			this.tick(now);
			this.raf = requestAnimationFrame(loop);
		};
		this.raf = requestAnimationFrame(loop);
	}
	stopLoop() {
		if (this.raf) cancelAnimationFrame(this.raf);
		this.raf = 0;
	}
	async startTransmit() {
		const store = useDetectorStore.getState();
		try {
			if (!this.audio) this.audio = new AudioContext();
			if (this.audio.state === "suspended") await this.audio.resume();
			if (!this.workletReady) {
				await this.audio.audioWorklet.addModule("/lockin-processor.js");
				this.workletReady = true;
			}
			if (!this.worklet) {
				this.worklet = new AudioWorkletNode(this.audio, "lock-in", {
					numberOfInputs: 1,
					numberOfOutputs: 1,
					outputChannelCount: [1]
				});
				this.worklet.port.onmessage = (event) => {
					this.rawI = event.data.i;
					this.rawQ = event.data.q;
				};
				this.txAnalyser = this.audio.createAnalyser();
				this.txAnalyser.fftSize = 512;
				this.txAnalyser.smoothingTimeConstant = 0;
				this.worklet.connect(this.txAnalyser);
				this.worklet.connect(this.audio.destination);
			}
			this.applyAudioParams();
			if (store.mode === "live") await this.connectMic();
			this.setupBeep();
			useDetectorStore.getState().setTransmitting(true);
			useDetectorStore.getState().setError(null);
		} catch (err) {
			const message = err instanceof Error ? err.message : "تعذّر تشغيل الصوت أو الميكروفون.";
			useDetectorStore.getState().setError(this.friendlyError(message));
			useDetectorStore.getState().setTransmitting(false);
			if (store.mode === "live") useDetectorStore.getState().setMode("sim");
		}
	}
	async connectMic() {
		if (!this.audio || !this.worklet) return;
		this.disconnectMic();
		this.stream = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: false,
			noiseSuppression: false,
			autoGainControl: false,
			channelCount: 1
		} });
		this.mic = this.audio.createMediaStreamSource(this.stream);
		this.rxAnalyser = this.audio.createAnalyser();
		this.rxAnalyser.fftSize = 512;
		this.rxAnalyser.smoothingTimeConstant = 0;
		this.mic.connect(this.rxAnalyser);
		this.mic.connect(this.worklet);
		this.beginCalibration(36);
	}
	stopTransmit() {
		this.disconnectMic();
		if (this.worklet) {
			this.worklet.disconnect();
			this.worklet.port.onmessage = null;
			this.worklet = null;
		}
		this.txAnalyser = null;
		this.rxAnalyser = null;
		this.teardownBeep();
		if (this.audio) this.audio.suspend();
		useDetectorStore.getState().setTransmitting(false);
	}
	beginCalibration(frames = 40) {
		this.calFrames = frames;
		this.calCount = frames;
		this.calI = 0;
		this.calQ = 0;
		useDetectorStore.getState().setCalibrating(true);
	}
	applyAudioParams() {
		if (!this.worklet) return;
		const { frequency, txGain } = useDetectorStore.getState().settings;
		const freq = this.worklet.parameters.get("frequency");
		const gain = this.worklet.parameters.get("txGain");
		freq?.setValueAtTime(frequency, this.audio?.currentTime ?? 0);
		gain?.setValueAtTime(txGain, this.audio?.currentTime ?? 0);
	}
	disconnectMic() {
		if (this.mic) {
			this.mic.disconnect();
			this.mic = null;
		}
		if (this.stream) {
			for (const track of this.stream.getTracks()) track.stop();
			this.stream = null;
		}
	}
	setupBeep() {
		if (!this.audio || this.beepOsc) return;
		this.beepOsc = this.audio.createOscillator();
		this.beepGain = this.audio.createGain();
		this.beepOsc.type = "sine";
		this.beepOsc.frequency.value = 440;
		this.beepGain.gain.value = 0;
		this.beepOsc.connect(this.beepGain);
		this.beepGain.connect(this.audio.destination);
		this.beepOsc.start();
	}
	teardownBeep() {
		if (this.beepOsc) {
			try {
				this.beepOsc.stop();
			} catch {}
			this.beepOsc.disconnect();
			this.beepOsc = null;
		}
		if (this.beepGain) {
			this.beepGain.disconnect();
			this.beepGain = null;
		}
	}
	friendlyError(message) {
		const lower = message.toLowerCase();
		if (lower.includes("permission") || lower.includes("denied") || lower.includes("notallowed")) return "الميكروفون محجوب. اسمح بالوصول أو استخدم وضع المحاكاة.";
		if (lower.includes("not found") || lower.includes("requested device")) return "لا يوجد ميكروفون. وصّل مدخل سماعة أو استخدم المحاكاة.";
		return "تعذّر فتح المسار الصوتي. يمكنك متابعة التحليل في وضع المحاكاة.";
	}
	tick(now) {
		const store = useDetectorStore.getState();
		const t = (now - this.startedAt) / 1e3;
		const { frequency, threshold, beep } = store.settings;
		if (store.autoDemo && store.mode === "sim" && now > this.demoUntil) {
			this.demoIndex = (this.demoIndex + 1) % METAL_SAMPLES.length;
			const next = METAL_SAMPLES[this.demoIndex];
			if (next) useDetectorStore.setState({
				sampleId: next.id,
				distance: .18
			});
			this.demoUntil = now + 4800;
		}
		const targetApproach = store.mode === "sim" && store.sampleId ? 1 - store.distance : store.mode === "live" ? 1 : 0;
		this.approach += (targetApproach - this.approach) * .07;
		let i = 0;
		let q = 0;
		if (store.mode === "sim") {
			const sample = sampleById(store.sampleId);
			const k = this.approach ** 3;
			const wobble = .018 * Math.sin(t * 6.7) + .01 * Math.sin(t * 11.9);
			i = (sample ? sample.r * k : 0) * (1 + wobble) + noise() * .008;
			q = (sample ? sample.x * k : 0) * (1 + wobble * .55) + noise() * .008;
			this.rawI = i;
			this.rawQ = q;
		} else {
			i = this.rawI;
			q = this.rawQ;
		}
		if (this.calFrames > 0) {
			this.calI += i;
			this.calQ += q;
			this.calFrames -= 1;
			if (this.calFrames === 0) {
				this.iCal = this.calI / this.calCount;
				this.qCal = this.calQ / this.calCount;
				useDetectorStore.getState().setCalibrating(false);
				useDetectorStore.getState().setCalibrated(true);
			}
		}
		const LIVE_GAIN = 10;
		const dI = store.mode === "sim" ? i : (i - this.iCal) * LIVE_GAIN;
		const dQ = store.mode === "sim" ? q : (q - this.qCal) * LIVE_GAIN;
		const reading = classify(dI, dQ, threshold);
		this.snapshot.t = t;
		this.snapshot.i = dI;
		this.snapshot.q = dQ;
		this.snapshot.mag = reading.mag;
		this.snapshot.phaseDeg = reading.phaseDeg;
		this.snapshot.vdi = reading.vdi;
		this.snapshot.kind = reading.kind;
		this.snapshot.confidence = reading.confidence;
		this.snapshot.label = reading.label;
		this.snapshot.detail = reading.detail;
		this.snapshot.running = store.running;
		this.snapshot.transmitting = store.transmitting;
		this.snapshot.approach = this.approach;
		const trail = this.snapshot.trail;
		trail.push({
			i: dI,
			q: dQ
		});
		if (trail.length > TRAIL) trail.splice(0, trail.length - TRAIL);
		this.paintWaves(t, frequency, reading.mag, reading.phaseDeg);
		if (this.beepOsc && this.beepGain && this.audio) {
			const on = beep && store.transmitting && reading.kind !== "empty";
			const freqHz = 280 + reading.vdi * 7.2;
			this.beepOsc.frequency.setTargetAtTime(freqHz, this.audio.currentTime, .04);
			this.beepGain.gain.setTargetAtTime(on ? .045 : 0, this.audio.currentTime, .05);
		}
		if (reading.kind !== "empty" && reading.kind !== "weak" && reading.kind !== this.lastKind && now - this.lastDetectAt > 900) {
			const sample = sampleById(store.sampleId);
			const detection = {
				id: `${now}`,
				at: Date.now(),
				kind: reading.kind,
				label: reading.label,
				phaseDeg: reading.phaseDeg,
				mag: reading.mag,
				vdi: reading.vdi,
				sampleName: store.mode === "sim" ? sample?.name : void 0
			};
			store.pushDetection(detection);
			this.lastDetectAt = now;
		}
		this.lastKind = reading.kind;
		if (now - this.lastUi > 70) {
			this.lastUi = now;
			store.setReading(reading);
			this.applyAudioParams();
		}
	}
	paintWaves(t, frequency, mag, phaseDeg) {
		const tx = this.snapshot.tx;
		const rx = this.snapshot.rx;
		const phase = phaseDeg * Math.PI / 180;
		const amp = Math.min(.95, .12 + mag * 1.15);
		if (this.txAnalyser && this.rxAnalyser) {
			this.txAnalyser.getFloatTimeDomainData(tx);
			this.rxAnalyser.getFloatTimeDomainData(rx);
			return;
		}
		if (this.txAnalyser) this.txAnalyser.getFloatTimeDomainData(tx);
		for (let n = 0; n < WAVE; n++) {
			const a = n / WAVE * 4 * TWO_PI + t * frequency * .002;
			if (!this.txAnalyser) tx[n] = Math.sin(a);
			rx[n] = amp * Math.sin(a + phase) + noise() * .03 * (1 - Math.min(1, mag));
		}
	}
};
var detectorEngine = new DetectorEngine();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 transition-[transform,background-color,color,opacity,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-card text-foreground shadow-border hover:shadow-border-hover",
			outline: "bg-transparent text-foreground shadow-border hover:bg-card",
			ghost: "bg-transparent text-muted hover:text-foreground hover:bg-card",
			signal: "bg-signal text-background hover:bg-signal/90",
			ferrous: "bg-ferrous text-background hover:bg-ferrous/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none select-none items-center", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-signal" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-border transition-[box-shadow,transform] duration-150 ease-out hover:shadow-border-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70" })]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full shadow-border transition-[background-color] duration-150 ease-out data-[state=checked]:bg-signal data-[state=unchecked]:bg-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 rounded-full bg-primary transition-transform duration-150 ease-out data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0.5" })
	});
}
function Controls() {
	const mode = useDetectorStore((s) => s.mode);
	const transmitting = useDetectorStore((s) => s.transmitting);
	const calibrating = useDetectorStore((s) => s.calibrating);
	const settings = useDetectorStore((s) => s.settings);
	const distance = useDetectorStore((s) => s.distance);
	const error = useDetectorStore((s) => s.error);
	const patchSettings = useDetectorStore((s) => s.patchSettings);
	const setMode = useDetectorStore((s) => s.setMode);
	const setDistance = useDetectorStore((s) => s.setDistance);
	async function toggleTx() {
		if (transmitting) {
			detectorEngine.stopTransmit();
			return;
		}
		await detectorEngine.startTransmit();
	}
	function calibrate() {
		detectorEngine.beginCalibration(40);
		toast.success("عُيّنت نقطة الصفر على الهواء");
	}
	async function chooseMode(next) {
		if (next === mode) return;
		if (transmitting) detectorEngine.stopTransmit();
		setMode(next);
		if (next === "live") await detectorEngine.startTransmit();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-border sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1 rounded-lg bg-plot p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void chooseMode("sim"),
					className: cn("flex h-10 items-center justify-center gap-1.5 rounded-md text-sm font-medium transition-[background-color,color] duration-150", mode === "sim" ? "bg-card text-foreground shadow-border" : "text-muted hover:text-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-3.5" }), "محاكاة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void chooseMode("live"),
					className: cn("flex h-10 items-center justify-center gap-1.5 rounded-md text-sm font-medium transition-[background-color,color] duration-150", mode === "live" ? "bg-card text-foreground shadow-border" : "text-muted hover:text-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-3.5" }), "مسار حي"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: transmitting ? "secondary" : "signal",
					className: "h-12",
					onClick: () => void toggleTx(),
					children: [transmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }), transmitting ? "إيقاف الإرسال" : "تشغيل الإرسال"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "h-12",
					onClick: calibrate,
					disabled: calibrating,
					children: calibrating ? "معايرة…" : "معايرة الهواء"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-ferrous",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تردد الإرسال",
						value: `${(settings.frequency / 1e3).toFixed(2)} kHz`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 2e3,
							max: 8e3,
							step: 50,
							value: [settings.frequency],
							onValueChange: ([v]) => patchSettings({ frequency: v ?? 4e3 }),
							dir: "ltr"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سعة الإرسال",
						value: `${Math.round(settings.txGain * 100)}%`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: .04,
							max: .7,
							step: .01,
							value: [settings.txGain],
							onValueChange: ([v]) => patchSettings({ txGain: v ?? .22 }),
							dir: "ltr"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "عتبة الكشف",
						value: settings.threshold.toFixed(3),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: .02,
							max: .28,
							step: .005,
							value: [settings.threshold],
							onValueChange: ([v]) => patchSettings({ threshold: v ?? .08 }),
							dir: "ltr"
						})
					}),
					mode === "sim" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مسافة الملف",
						value: `${Math.round(distance * 100)} سم`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: .02,
							max: .95,
							step: .01,
							value: [distance],
							onValueChange: ([v]) => setDistance(v ?? .22),
							dir: "ltr"
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "beep",
							className: "text-sm text-foreground",
							children: "نغمة التمييز"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "beep",
							dir: "ltr",
							checked: settings.beep,
							onCheckedChange: (beep) => patchSettings({ beep })
						})]
					})
				]
			})
		]
	});
}
function Field({ label, value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-baseline justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs tabular-nums text-muted",
			dir: "ltr",
			children: value
		})]
	}), children] });
}
function HistoryList() {
	const history = useDetectorStore((s) => s.history);
	const clearHistory = useDetectorStore((s) => s.clearHistory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-border sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-foreground",
				children: "سجل الكشف"
			}), history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: clearHistory,
				className: "text-xs text-muted transition-colors duration-150 hover:text-foreground",
				children: "مسح"
			}) : null]
		}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "تظهر هنا الأهداف بعد تجاوز العتبة. في المحاكاة اختر معدناً وقرّب الملف."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1.5",
			children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 rounded-md bg-plot px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-foreground",
						children: item.sampleName ?? item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: new Date(item.at).toLocaleTimeString("ar", {
							hour: "2-digit",
							minute: "2-digit",
							second: "2-digit"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-xs font-medium", item.kind === "ferrous" ? "text-ferrous" : "text-nonferrous"),
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-[11px] tabular-nums text-muted",
						dir: "ltr",
						children: [
							item.phaseDeg.toFixed(0),
							"° · VDI ",
							item.vdi
						]
					})]
				})]
			}, item.id))
		})]
	});
}
function cssVar(name, fallback) {
	if (typeof document === "undefined") return fallback;
	return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
}
function fitCanvas(canvas) {
	const dpr = Math.min(window.devicePixelRatio || 1, 2);
	const rect = canvas.getBoundingClientRect();
	const width = Math.max(1, Math.floor(rect.width * dpr));
	const height = Math.max(1, Math.floor(rect.height * dpr));
	if (canvas.width !== width || canvas.height !== height) {
		canvas.width = width;
		canvas.height = height;
	}
	return {
		width,
		height,
		dpr,
		cssW: rect.width,
		cssH: rect.height
	};
}
function IqPlot() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		let raf = 0;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const draw = () => {
			const { width, height } = fitCanvas(canvas);
			const snap = detectorEngine.snapshot;
			const bg = cssVar("--color-plot", "#101411");
			const grid = cssVar("--color-border", "#2a2e2a");
			const muted = cssVar("--color-muted", "#8b9186");
			const ferrous = cssVar("--color-ferrous", "#c4785a");
			const nonferrous = cssVar("--color-nonferrous", "#7a9eb0");
			const signal = cssVar("--color-signal", "#7dba8a");
			const fg = cssVar("--color-foreground", "#eceee9");
			ctx.clearRect(0, 0, width, height);
			ctx.fillStyle = bg;
			ctx.fillRect(0, 0, width, height);
			const cx = width / 2;
			const cy = height / 2;
			const scale = Math.min(width, height) * .38;
			ctx.save();
			ctx.translate(cx, cy);
			ctx.globalAlpha = .14;
			ctx.fillStyle = ferrous;
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.arc(0, 0, scale, -Math.PI * .72, -Math.PI * .28);
			ctx.closePath();
			ctx.fill();
			ctx.fillStyle = nonferrous;
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.arc(0, 0, scale, -Math.PI * .22, Math.PI * .22);
			ctx.closePath();
			ctx.fill();
			ctx.globalAlpha = 1;
			ctx.strokeStyle = grid;
			ctx.lineWidth = Math.max(1, width / 420);
			for (const r of [
				.33,
				.66,
				1
			]) {
				ctx.beginPath();
				ctx.arc(0, 0, scale * r, 0, Math.PI * 2);
				ctx.stroke();
			}
			ctx.beginPath();
			ctx.moveTo(-scale * 1.08, 0);
			ctx.lineTo(scale * 1.08, 0);
			ctx.moveTo(0, -scale * 1.08);
			ctx.lineTo(0, scale * 1.08);
			ctx.stroke();
			ctx.fillStyle = muted;
			ctx.font = `${Math.round(width * .032)}px "IBM Plex Sans Arabic", sans-serif`;
			ctx.textAlign = "center";
			ctx.fillText("X نفاذية", 0, -scale * 1.14);
			ctx.textAlign = "left";
			ctx.fillText("R موصلية", scale * .72, 16);
			const trail = snap.trail;
			if (trail.length > 1) {
				ctx.beginPath();
				for (let i = 0; i < trail.length; i++) {
					const p = trail[i];
					const x = p.i * scale * 1.05;
					const y = -p.q * scale * 1.05;
					if (i === 0) ctx.moveTo(x, y);
					else ctx.lineTo(x, y);
				}
				ctx.strokeStyle = signal;
				ctx.globalAlpha = .35;
				ctx.lineWidth = Math.max(1.2, width / 280);
				ctx.stroke();
				ctx.globalAlpha = 1;
			}
			const vx = snap.i * scale * 1.05;
			const vy = -snap.q * scale * 1.05;
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.lineTo(vx, vy);
			ctx.strokeStyle = snap.kind === "ferrous" ? ferrous : snap.kind === "nonferrous" ? nonferrous : signal;
			ctx.lineWidth = Math.max(2, width / 200);
			ctx.stroke();
			ctx.beginPath();
			ctx.arc(vx, vy, Math.max(4, width / 90), 0, Math.PI * 2);
			ctx.fillStyle = fg;
			ctx.fill();
			ctx.restore();
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-[240px] flex-col rounded-xl bg-card p-3 shadow-border sm:min-h-[280px] sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-foreground",
				children: "مستوى الطور I/Q"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "محور R موصلية · محور X نفاذية"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "h-full min-h-[200px] w-full flex-1 rounded-lg"
		})]
	});
}
function PhaseDial() {
	const angle = useDetectorStore((s) => s.reading).phaseDeg;
	const needle = -angle;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[148px] flex-col rounded-xl bg-card p-3 shadow-border sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 text-sm font-medium text-foreground",
			children: "فرق الطور"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 160 160",
				className: "size-[112px] shrink-0 sm:size-[128px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "80",
						cy: "80",
						r: "62",
						fill: "var(--color-plot)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "80",
						cy: "80",
						r: "62",
						fill: "none",
						stroke: "var(--color-border)",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M80 80 L142 80 A62 62 0 0 0 80 18 Z",
						fill: "var(--color-nonferrous)",
						opacity: "0.18"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M80 80 L80 18 A62 62 0 0 0 18 80 Z",
						fill: "var(--color-ferrous)",
						opacity: "0.18"
					}),
					[
						0,
						45,
						90,
						135,
						180,
						-45,
						-90,
						-135
					].map((deg) => {
						const rad = deg * Math.PI / 180;
						const x1 = 80 + Math.cos(rad) * 54;
						const y1 = 80 - Math.sin(rad) * 54;
						const x2 = 80 + Math.cos(rad) * 62;
						const y2 = 80 - Math.sin(rad) * 62;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1,
							y1,
							x2,
							y2,
							stroke: "var(--color-muted)",
							strokeWidth: "1.2"
						}, deg);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						style: {
							transform: `rotate(${needle}deg)`,
							transformOrigin: "80px 80px",
							transition: "transform 120ms cubic-bezier(0.22, 1, 0.36, 1)"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "80",
							y1: "80",
							x2: "132",
							y2: "80",
							stroke: "var(--color-signal)",
							strokeWidth: "2.4",
							strokeLinecap: "round"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "80",
							cy: "80",
							r: "4",
							fill: "var(--color-foreground)"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "132",
						y: "76",
						fill: "var(--color-muted)",
						fontSize: "8",
						children: "0°"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "72",
						y: "24",
						fill: "var(--color-muted)",
						fontSize: "8",
						children: "90°"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-3xl font-medium tabular-nums leading-none tracking-tight text-foreground",
					dir: "ltr",
					children: [
						angle >= 0 ? "+" : "",
						angle.toFixed(1),
						"°"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs leading-relaxed text-muted",
					children: "الزاوية بين إشارة الإرسال 4 كيلوهرتز والإشارة المرتدة بعد طرح معايرة الهواء."
				})]
			})]
		})]
	});
}
function Readout() {
	const reading = useDetectorStore((s) => s.reading);
	const calibrated = useDetectorStore((s) => s.calibrated);
	const calibrating = useDetectorStore((s) => s.calibrating);
	const mode = useDetectorStore((s) => s.mode);
	const transmitting = useDetectorStore((s) => s.transmitting);
	const tone = reading.kind === "ferrous" ? "text-ferrous" : reading.kind === "nonferrous" ? "text-nonferrous" : reading.kind === "weak" ? "text-signal" : "text-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-border sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted",
						children: "التصنيف"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-1 text-3xl font-medium leading-none tracking-tight sm:text-4xl", tone),
						children: reading.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-sm leading-relaxed text-muted text-pretty",
						children: reading.detail
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPills, {
					mode,
					transmitting,
					calibrated,
					calibrating
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "فرق الطور",
						value: `${reading.phaseDeg >= 0 ? "+" : ""}${reading.phaseDeg.toFixed(1)}°`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "الشدة |Z|",
						value: reading.mag.toFixed(3)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "مؤشر التمييز",
						value: String(reading.vdi).padStart(2, "0"),
						hint: "VDI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "الثقة",
						value: `${Math.round(reading.confidence * 100)}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1.5 flex items-center justify-between text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-3.5" }), "شدة الإشارة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Magnet, { className: "size-3.5" }), reading.kind === "ferrous" ? "نفاذية غالبة" : reading.kind === "nonferrous" ? "موصلية غالبة" : "متوازن"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full transition-[width,background-color] duration-200 ease-out", reading.kind === "ferrous" ? "bg-ferrous" : reading.kind === "nonferrous" ? "bg-nonferrous" : "bg-signal"),
						style: { width: `${Math.min(100, reading.mag * 110)}%` }
					})
				})]
			})
		]
	});
}
function Metric({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-plot px-3 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
			className: "text-[11px] text-muted",
			children: [label, hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-1 font-mono opacity-70",
				children: hint
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-mono text-lg font-medium tabular-nums tracking-tight text-foreground",
			dir: "ltr",
			children: value
		})]
	});
}
function StatusPills({ mode, transmitting, calibrated, calibrating }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "flex flex-wrap gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted",
				children: mode === "sim" ? "محاكاة" : "مسار حي"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: transmitting ? "rounded-full bg-signal/15 px-2.5 py-1 text-[11px] text-signal" : "rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted",
				children: transmitting ? "إرسال 4 kHz" : "الإرسال متوقف"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: calibrated ? "rounded-full bg-plot px-2.5 py-1 text-[11px] text-foreground" : "rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted",
				children: calibrating ? "جارٍ المعايرة…" : calibrated ? "معايرة هواء جاهزة" : "بلا معايرة"
			})
		]
	});
}
function SamplesPanel() {
	const mode = useDetectorStore((s) => s.mode);
	const sampleId = useDetectorStore((s) => s.sampleId);
	const setSampleId = useDetectorStore((s) => s.setSampleId);
	const setDistance = useDetectorStore((s) => s.setDistance);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-border sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-foreground",
					children: "عينات المعادن"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: mode === "sim" ? "اضغط لتقريب الملف" : "مرجع بصري فقط"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-2 gap-2",
				children: METAL_SAMPLES.map((sample) => {
					const active = sampleId === sample.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							if (active) {
								setSampleId(null);
								setDistance(.85);
								return;
							}
							setSampleId(sample.id);
							setDistance(.16);
						},
						className: cn("flex h-[72px] w-full flex-col items-start justify-center rounded-lg px-3 text-start transition-[background-color,box-shadow,color] duration-150", active ? "bg-plot shadow-border-hover" : "bg-plot/60 shadow-border hover:shadow-border-hover"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex w-full items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-foreground",
								children: sample.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-mono text-[10px] tabular-nums", sample.kind === "ferrous" ? "text-ferrous" : "text-nonferrous"),
								dir: "ltr",
								children: sample.latin
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-[11px] text-muted",
							children: sample.kind === "ferrous" ? "حديدي · طور مرتفع" : "غير حديدي · طور منخفض"
						})]
					}) }, sample.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setSampleId(null);
					setDistance(.9);
				},
				className: "mt-2 h-10 w-full rounded-lg text-sm text-muted transition-colors duration-150 hover:bg-plot hover:text-foreground",
				children: "هواء — بلا هدف"
			})
		]
	});
}
var STEPS = [
	{
		title: "الإرسال 4 كيلوهرتز",
		body: "يولد التطبيق موجة جيبية ثابتة على مخرج الصوت. هذا هو الحقل الابتدائي. وصّل سماعة أو ملف إرسال على مخرج الأذن."
	},
	{
		title: "الاستقبال",
		body: "مدخَل الميكروفون يلتقط الإشارة المرتدة — إمّا اقتراناً كهرومغناطيسياً من ملف استقبال، أو اقتراناً صوتياً/حثياً ضعيفاً من السماعة نفسها."
	},
	{
		title: "قفل الطور",
		body: "يُضرب الاستقبال في جيبي وجيب تمام الإرسال (مضخم قفل) لاستخراج المركّبتين: R المقاومة (تيارات دوامية / موصلية) و X التفاعلية (نفاذية)."
	},
	{
		title: "معايرة الهواء",
		body: "اطرح متجه الهواء ليصبح الأصل هو «لا معدن». أي هدف يظهر كمتجه فرق طور. الحديد يميل نحو X، والنحاس والألومنيوم نحو R."
	},
	{
		title: "ملف بحث بسيط",
		body: "50–120 لفة سلك نحاسي على إطار 10–20 سم، مقاومة 100Ω على مخرج السماعة. ملف أصغر إلى مدخل الميكروفون. عطّل إلغاء الصدى في النظام."
	}
];
function SetupGuide() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-4 shadow-border sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			className: "flex h-11 w-full items-center justify-between gap-3 text-start",
			"aria-expanded": open,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-foreground",
				children: "كيف يعمل الجهاز"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 text-muted transition-transform duration-200 ease-out", open && "rotate-180") })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("grid transition-[grid-template-rows,opacity] duration-200 ease-out", open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-3 pb-1 pt-2",
					children: STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-plot font-mono text-[11px] text-muted",
							children: i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: step.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted text-pretty",
							children: step.body
						})] })]
					}, step.title))
				})
			})
		})]
	});
}
function Waveform() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const draw = () => {
			const { width, height } = fitCanvas(canvas);
			const snap = detectorEngine.snapshot;
			const bg = cssVar("--color-plot", "#101411");
			const txColor = cssVar("--color-muted", "#8b9186");
			const rxColor = cssVar("--color-signal", "#7dba8a");
			const grid = cssVar("--color-border", "#2a2e2a");
			ctx.fillStyle = bg;
			ctx.fillRect(0, 0, width, height);
			ctx.strokeStyle = grid;
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(0, height / 2);
			ctx.lineTo(width, height / 2);
			ctx.stroke();
			const paint = (data, color, alpha) => {
				ctx.beginPath();
				const n = data.length;
				for (let i = 0; i < n; i++) {
					const x = i / (n - 1) * width;
					const y = height / 2 - data[i] * height * .38;
					if (i === 0) ctx.moveTo(x, y);
					else ctx.lineTo(x, y);
				}
				ctx.strokeStyle = color;
				ctx.globalAlpha = alpha;
				ctx.lineWidth = Math.max(1.25, width / 360);
				ctx.stroke();
				ctx.globalAlpha = 1;
			};
			paint(snap.tx, txColor, .55);
			paint(snap.rx, rxColor, .95);
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[148px] flex-col rounded-xl bg-card p-3 shadow-border sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-foreground",
				children: "الإرسال والاستقبال"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "إرسال"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-signal",
					children: "استقبال"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "h-[112px] w-full rounded-lg sm:h-[128px]"
		})]
	});
}
function Instrument() {
	const frequency = useDetectorStore((s) => s.settings.frequency);
	const transmitting = useDetectorStore((s) => s.transmitting);
	(0, import_react.useEffect)(() => {
		detectorEngine.start();
		return () => {
			detectorEngine.stopLoop();
			detectorEngine.stopTransmit();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				dir: "rtl",
				richColors: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative flex size-9 items-center justify-center rounded-md bg-plot shadow-border",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: transmitting ? "size-2 rounded-full bg-signal motion-safe:animate-led" : "size-2 rounded-full bg-muted" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-medium leading-none tracking-tight",
							children: "حديدار"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "كاشف المعادن بفرق الطور الصوتي"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm tabular-nums text-signal",
						dir: "ltr",
						children: [(frequency / 1e3).toFixed(3), " kHz VLF"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-6xl gap-4 px-4 py-4 sm:px-6 sm:py-6 lg:grid-cols-[minmax(0,1fr)_20rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IqPlot, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhaseDial, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col gap-4 lg:sticky lg:top-4 lg:self-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Controls, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamplesPanel, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupGuide, {})
					]
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instrument, {});
}
//#endregion
export { Home as component };
