/**
 * Lock-in amplifier worklet.
 * Outputs a 4 kHz (adjustable) sine on the speaker, and demodulates the
 * microphone input against the same oscillator (I = cos, Q = sin).
 */
class LockInProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      {
        name: "frequency",
        defaultValue: 4000,
        minValue: 500,
        maxValue: 10000,
        automationRate: "k-rate",
      },
      {
        name: "txGain",
        defaultValue: 0.22,
        minValue: 0,
        maxValue: 0.85,
        automationRate: "k-rate",
      },
    ];
  }

  constructor() {
    super();
    this.phase = 0;
    this.iEma = 0;
    this.qEma = 0;
    this.alpha = 0.00028;
    this.frames = 0;
    this.port.onmessage = (event) => {
      const data = event.data;
      if (data && data.type === "alpha" && typeof data.value === "number") {
        this.alpha = data.value;
      }
    };
  }

  process(inputs, outputs, parameters) {
    const output = outputs[0]?.[0];
    if (!output) return true;

    const input = inputs[0]?.[0];
    const freq = parameters.frequency[0] ?? 4000;
    const txGain = parameters.txGain[0] ?? 0.22;
    const omega = (2 * Math.PI * freq) / sampleRate;
    const alpha = this.alpha;

    for (let n = 0; n < output.length; n++) {
      const s = Math.sin(this.phase);
      const c = Math.cos(this.phase);
      output[n] = s * txGain;
      const x = input ? input[n] : 0;
      this.iEma += alpha * (x * c - this.iEma);
      this.qEma += alpha * (x * s - this.qEma);
      this.phase += omega;
      if (this.phase > Math.PI * 2) this.phase -= Math.PI * 2;
    }

    this.frames += 1;
    if (this.frames % 4 === 0) {
      this.port.postMessage({
        i: this.iEma,
        q: this.qEma,
      });
    }

    return true;
  }
}

registerProcessor("lock-in", LockInProcessor);
