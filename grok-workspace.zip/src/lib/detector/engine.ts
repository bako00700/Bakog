import { classify } from "./classifier";
import { METAL_SAMPLES, sampleById } from "./samples";
import { useDetectorStore } from "./store";
import type { Detection, Snapshot } from "./types";

const WAVE = 512;
const TRAIL = 140;
const TWO_PI = Math.PI * 2;

function makeWave() {
  return new Float32Array(WAVE);
}

function emptySnapshot(): Snapshot {
  return {
    t: 0,
    i: 0,
    q: 0,
    mag: 0,
    phaseDeg: 0,
    vdi: 0,
    kind: "empty",
    confidence: 1,
    label: "فراغ",
    detail: "",
    running: false,
    transmitting: false,
    approach: 0,
    tx: makeWave(),
    rx: makeWave(),
    trail: [],
  };
}

function noise() {
  return (Math.random() - 0.5) * 2;
}

export class DetectorEngine {
  snapshot: Snapshot = emptySnapshot();

  private raf = 0;
  private startedAt = 0;
  private approach = 0.72;
  private rawI = 0;
  private rawQ = 0;
  private iCal = 0;
  private qCal = 0;
  private calFrames = 0;
  private calI = 0;
  private calQ = 0;
  private lastKind = "empty";
  private lastDetectAt = 0;
  private demoIndex = 0;
  private demoUntil = 0;
  private audio: AudioContext | null = null;
  private worklet: AudioWorkletNode | null = null;
  private mic: MediaStreamAudioSourceNode | null = null;
  private stream: MediaStream | null = null;
  private txAnalyser: AnalyserNode | null = null;
  private rxAnalyser: AnalyserNode | null = null;
  private beepOsc: OscillatorNode | null = null;
  private beepGain: GainNode | null = null;
  private calCount = 40;
  private lastUi = 0;
  private workletReady = false;

  start() {
    if (this.raf) return;
    this.startedAt = performance.now();
    this.demoUntil = this.startedAt + 4200;
    const loop = (now: number) => {
      this.tick(now);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  stopLoop() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  async startTransmit() {
    const store = useDetectorStore.getState();
    try {
      if (!this.audio) {
        this.audio = new AudioContext();
      }
      if (this.audio.state === "suspended") {
        await this.audio.resume();
      }
      if (!this.workletReady) {
        await this.audio.audioWorklet.addModule("/lockin-processor.js");
        this.workletReady = true;
      }
      if (!this.worklet) {
        this.worklet = new AudioWorkletNode(this.audio, "lock-in", {
          numberOfInputs: 1,
          numberOfOutputs: 1,
          outputChannelCount: [1],
        });
        this.worklet.port.onmessage = (event: MessageEvent<{ i: number; q: number }>) => {
          this.rawI = event.data.i;
          this.rawQ = event.data.q;
        };
        this.txAnalyser = this.audio.createAnalyser();
        this.txAnalyser.fftSize = 512;
        this.txAnalyser.smoothingTimeConstant = 0;
        this.worklet.connect(this.txAnalyser);
        this.worklet.connect(this.audio.destination);
      }
      this.applyAudioParams();

      if (store.mode === "live") {
        await this.connectMic();
      }

      this.setupBeep();
      useDetectorStore.getState().setTransmitting(true);
      useDetectorStore.getState().setError(null);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "تعذّر تشغيل الصوت أو الميكروفون.";
      useDetectorStore.getState().setError(this.friendlyError(message));
      useDetectorStore.getState().setTransmitting(false);
      if (store.mode === "live") {
        useDetectorStore.getState().setMode("sim");
      }
    }
  }

  async connectMic() {
    if (!this.audio || !this.worklet) return;
    this.disconnectMic();
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false,
        channelCount: 1,
      },
    });
    this.mic = this.audio.createMediaStreamSource(this.stream);
    this.rxAnalyser = this.audio.createAnalyser();
    this.rxAnalyser.fftSize = 512;
    this.rxAnalyser.smoothingTimeConstant = 0;
    this.mic.connect(this.rxAnalyser);
    this.mic.connect(this.worklet);
    this.beginCalibration(36);
  }

  stopTransmit() {
    this.disconnectMic();
    if (this.worklet) {
      this.worklet.disconnect();
      this.worklet.port.onmessage = null;
      this.worklet = null;
    }
    this.txAnalyser = null;
    this.rxAnalyser = null;
    this.teardownBeep();
    if (this.audio) {
      void this.audio.suspend();
    }
    useDetectorStore.getState().setTransmitting(false);
  }

  beginCalibration(frames = 40) {
    this.calFrames = frames;
    this.calCount = frames;
    this.calI = 0;
    this.calQ = 0;
    useDetectorStore.getState().setCalibrating(true);
  }

  applyAudioParams() {
    if (!this.worklet) return;
    const { frequency, txGain } = useDetectorStore.getState().settings;
    const freq = this.worklet.parameters.get("frequency");
    const gain = this.worklet.parameters.get("txGain");
    freq?.setValueAtTime(frequency, this.audio?.currentTime ?? 0);
    gain?.setValueAtTime(txGain, this.audio?.currentTime ?? 0);
  }

  private disconnectMic() {
    if (this.mic) {
      this.mic.disconnect();
      this.mic = null;
    }
    if (this.stream) {
      for (const track of this.stream.getTracks()) track.stop();
      this.stream = null;
    }
  }

  private setupBeep() {
    if (!this.audio || this.beepOsc) return;
    this.beepOsc = this.audio.createOscillator();
    this.beepGain = this.audio.createGain();
    this.beepOsc.type = "sine";
    this.beepOsc.frequency.value = 440;
    this.beepGain.gain.value = 0;
    this.beepOsc.connect(this.beepGain);
    this.beepGain.connect(this.audio.destination);
    this.beepOsc.start();
  }

  private teardownBeep() {
    if (this.beepOsc) {
      try {
        this.beepOsc.stop();
      } catch {
        /* already stopped */
      }
      this.beepOsc.disconnect();
      this.beepOsc = null;
    }
    if (this.beepGain) {
      this.beepGain.disconnect();
      this.beepGain = null;
    }
  }

  private friendlyError(message: string) {
    const lower = message.toLowerCase();
    if (lower.includes("permission") || lower.includes("denied") || lower.includes("notallowed")) {
      return "الميكروفون محجوب. اسمح بالوصول أو استخدم وضع المحاكاة.";
    }
    if (lower.includes("not found") || lower.includes("requested device")) {
      return "لا يوجد ميكروفون. وصّل مدخل سماعة أو استخدم المحاكاة.";
    }
    return "تعذّر فتح المسار الصوتي. يمكنك متابعة التحليل في وضع المحاكاة.";
  }

  private tick(now: number) {
    const store = useDetectorStore.getState();
    const t = (now - this.startedAt) / 1000;
    const { frequency, threshold, beep } = store.settings;

    if (store.autoDemo && store.mode === "sim" && now > this.demoUntil) {
      this.demoIndex = (this.demoIndex + 1) % METAL_SAMPLES.length;
      const next = METAL_SAMPLES[this.demoIndex];
      if (next) {
        useDetectorStore.setState({ sampleId: next.id, distance: 0.18 });
      }
      this.demoUntil = now + 4800;
    }

    const targetApproach =
      store.mode === "sim" && store.sampleId ? 1 - store.distance : store.mode === "live" ? 1 : 0;
    this.approach += (targetApproach - this.approach) * 0.07;

    let i = 0;
    let q = 0;

    if (store.mode === "sim") {
      const sample = sampleById(store.sampleId);
      const k = this.approach ** 3;
      const wobble = 0.018 * Math.sin(t * 6.7) + 0.01 * Math.sin(t * 11.9);
      i = (sample ? sample.r * k : 0) * (1 + wobble) + noise() * 0.008;
      q = (sample ? sample.x * k : 0) * (1 + wobble * 0.55) + noise() * 0.008;
      this.rawI = i;
      this.rawQ = q;
    } else {
      i = this.rawI;
      q = this.rawQ;
    }

    if (this.calFrames > 0) {
      this.calI += i;
      this.calQ += q;
      this.calFrames -= 1;
      if (this.calFrames === 0) {
        this.iCal = this.calI / this.calCount;
        this.qCal = this.calQ / this.calCount;
        useDetectorStore.getState().setCalibrating(false);
        useDetectorStore.getState().setCalibrated(true);
      }
    }

    const LIVE_GAIN = 10;
    const dI = store.mode === "sim" ? i : (i - this.iCal) * LIVE_GAIN;
    const dQ = store.mode === "sim" ? q : (q - this.qCal) * LIVE_GAIN;
    const reading = classify(dI, dQ, threshold);

    this.snapshot.t = t;
    this.snapshot.i = dI;
    this.snapshot.q = dQ;
    this.snapshot.mag = reading.mag;
    this.snapshot.phaseDeg = reading.phaseDeg;
    this.snapshot.vdi = reading.vdi;
    this.snapshot.kind = reading.kind;
    this.snapshot.confidence = reading.confidence;
    this.snapshot.label = reading.label;
    this.snapshot.detail = reading.detail;
    this.snapshot.running = store.running;
    this.snapshot.transmitting = store.transmitting;
    this.snapshot.approach = this.approach;

    const trail = this.snapshot.trail;
    trail.push({ i: dI, q: dQ });
    if (trail.length > TRAIL) trail.splice(0, trail.length - TRAIL);

    this.paintWaves(t, frequency, reading.mag, reading.phaseDeg);

    if (this.beepOsc && this.beepGain && this.audio) {
      const on = beep && store.transmitting && reading.kind !== "empty";
      const freqHz = 280 + reading.vdi * 7.2;
      this.beepOsc.frequency.setTargetAtTime(freqHz, this.audio.currentTime, 0.04);
      this.beepGain.gain.setTargetAtTime(on ? 0.045 : 0, this.audio.currentTime, 0.05);
    }

    if (
      reading.kind !== "empty" &&
      reading.kind !== "weak" &&
      reading.kind !== this.lastKind &&
      now - this.lastDetectAt > 900
    ) {
      const sample = sampleById(store.sampleId);
      const detection: Detection = {
        id: `${now}`,
        at: Date.now(),
        kind: reading.kind,
        label: reading.label,
        phaseDeg: reading.phaseDeg,
        mag: reading.mag,
        vdi: reading.vdi,
        sampleName: store.mode === "sim" ? sample?.name : undefined,
      };
      store.pushDetection(detection);
      this.lastDetectAt = now;
    }
    this.lastKind = reading.kind;

    if (now - this.lastUi > 70) {
      this.lastUi = now;
      store.setReading(reading);
      this.applyAudioParams();
    }
  }

  private paintWaves(t: number, frequency: number, mag: number, phaseDeg: number) {
    const tx = this.snapshot.tx;
    const rx = this.snapshot.rx;
    const phase = (phaseDeg * Math.PI) / 180;
    const amp = Math.min(0.95, 0.12 + mag * 1.15);

    if (this.txAnalyser && this.rxAnalyser) {
      this.txAnalyser.getFloatTimeDomainData(tx as Float32Array<ArrayBuffer>);
      this.rxAnalyser.getFloatTimeDomainData(rx as Float32Array<ArrayBuffer>);
      return;
    }

    if (this.txAnalyser) {
      this.txAnalyser.getFloatTimeDomainData(tx as Float32Array<ArrayBuffer>);
    }

    for (let n = 0; n < WAVE; n++) {
      const a = (n / WAVE) * 4 * TWO_PI + t * frequency * 0.002;
      if (!this.txAnalyser) tx[n] = Math.sin(a);
      rx[n] = amp * Math.sin(a + phase) + noise() * 0.03 * (1 - Math.min(1, mag));
    }
  }
}

export const detectorEngine = new DetectorEngine();
