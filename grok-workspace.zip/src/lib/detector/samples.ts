import type { MetalSample } from "./types";

/** Physically-motivated R/X signatures at ~4 kHz VLF. */
export const METAL_SAMPLES: MetalSample[] = [
  {
    id: "iron-nail",
    name: "مسمار حديد",
    latin: "Fe",
    kind: "ferrous",
    r: 0.16,
    x: 0.78,
    note: "نفاذية عالية، تيارات دوامية ضعيفة نسبياً.",
  },
  {
    id: "steel",
    name: "فولاذ",
    latin: "Steel",
    kind: "ferrous",
    r: 0.26,
    x: 0.66,
    note: "حديدي مخلوط — طور مرتفع مع بعض الفقد.",
  },
  {
    id: "ferrite",
    name: "فريت",
    latin: "Ferrite",
    kind: "ferrous",
    r: 0.05,
    x: 0.9,
    note: "شبه محض تفاعلي — مرجع نفاذية.",
  },
  {
    id: "copper",
    name: "نحاس",
    latin: "Cu",
    kind: "nonferrous",
    r: 0.84,
    x: 0.16,
    note: "موصلية عالية، طور منخفض.",
  },
  {
    id: "aluminum",
    name: "ألومنيوم",
    latin: "Al",
    kind: "nonferrous",
    r: 0.72,
    x: 0.22,
    note: "تيارات دوامية قوية على 4 كيلوهرتز.",
  },
  {
    id: "gold",
    name: "ذهب",
    latin: "Au",
    kind: "nonferrous",
    r: 0.5,
    x: 0.3,
    note: "موصلية متوسطة — يقع بين الألومنيوم والحديد على محور التمييز.",
  },
  {
    id: "silver",
    name: "فضة",
    latin: "Ag",
    kind: "nonferrous",
    r: 0.9,
    x: 0.12,
    note: "أعلى موصليات شائعة — أقرب إلى محور R.",
  },
];

export function sampleById(id: string | null): MetalSample | undefined {
  if (!id) return undefined;
  return METAL_SAMPLES.find((s) => s.id === id);
}
