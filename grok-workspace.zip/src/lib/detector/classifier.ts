import type { Classification, MetalKind } from "./types";

const FERROUS_PHASE = 42;

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function classify(dI: number, dQ: number, threshold: number): Classification {
  const mag = Math.hypot(dI, dQ);
  const phaseDeg = (Math.atan2(dQ, dI) * 180) / Math.PI;
  const absPhase = Math.min(90, Math.abs(phaseDeg));
  const vdi = clamp(Math.round(99 * (1 - absPhase / 90)), 0, 99);

  if (mag < threshold) {
    return {
      kind: "empty",
      phaseDeg,
      mag,
      vdi: 0,
      confidence: 1,
      label: "فراغ",
      detail: "لا يوجد هدف فوق العتبة — عاير في الهواء ثم قرّب المعدن من الملف.",
    };
  }

  const confidence = clamp((mag - threshold) / (threshold * 2.4), 0.28, 0.98);

  if (mag < threshold * 1.35) {
    return {
      kind: "weak",
      phaseDeg,
      mag,
      vdi,
      confidence,
      label: "إشارة ضعيفة",
      detail: "اقترب أكثر أو ارفع الحساسية. الطور غير كافٍ للتمييز بعد.",
    };
  }

  if (absPhase >= FERROUS_PHASE) {
    return {
      kind: "ferrous",
      phaseDeg,
      mag,
      vdi,
      confidence,
      label: "معدن حديدي",
      detail: "مكوّن تفاعلي (X) غالب — نفاذية مغناطيسية مرتفعة، نمط الحديد والفولاذ.",
    };
  }

  return {
    kind: "nonferrous",
    phaseDeg,
    mag,
    vdi,
    confidence,
    label: "غير حديدي",
    detail: "مكوّن مقاومي (R) غالب — تيارات دوامية من النحاس أو الألومنيوم أو الذهب.",
  };
}

export function kindTone(kind: MetalKind): string {
  switch (kind) {
    case "ferrous":
      return "var(--color-ferrous)";
    case "nonferrous":
      return "var(--color-nonferrous)";
    case "weak":
      return "var(--color-signal)";
    default:
      return "var(--color-muted)";
  }
}
