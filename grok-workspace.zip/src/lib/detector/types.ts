export type DetectorMode = "sim" | "live";

export type MetalKind = "empty" | "weak" | "ferrous" | "nonferrous";

export type MetalSample = {
  id: string;
  name: string;
  latin: string;
  kind: Exclude<MetalKind, "empty" | "weak">;
  /** Resistive (eddy / conductivity) component, 0–1. */
  r: number;
  /** Reactive (permeability / inductance) component, 0–1. */
  x: number;
  note: string;
};

export type Classification = {
  kind: MetalKind;
  phaseDeg: number;
  mag: number;
  vdi: number;
  confidence: number;
  label: string;
  detail: string;
};

export type Detection = {
  id: string;
  at: number;
  kind: MetalKind;
  label: string;
  phaseDeg: number;
  mag: number;
  vdi: number;
  sampleName?: string;
};

export type Snapshot = {
  t: number;
  i: number;
  q: number;
  mag: number;
  phaseDeg: number;
  vdi: number;
  kind: MetalKind;
  confidence: number;
  label: string;
  detail: string;
  running: boolean;
  transmitting: boolean;
  approach: number;
  tx: Float32Array;
  rx: Float32Array;
  trail: Array<{ i: number; q: number }>;
};
