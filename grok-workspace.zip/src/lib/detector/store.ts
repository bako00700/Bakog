import { create } from "zustand";
import type { Classification, Detection, DetectorMode } from "./types";

const emptyClass: Classification = {
  kind: "empty",
  phaseDeg: 0,
  mag: 0,
  vdi: 0,
  confidence: 1,
  label: "فراغ",
  detail: "شغّل الإرسال ثم عاير في الهواء.",
};

export type DetectorSettings = {
  frequency: number;
  txGain: number;
  threshold: number;
  beep: boolean;
};

type DetectorStore = {
  mode: DetectorMode;
  running: boolean;
  transmitting: boolean;
  calibrating: boolean;
  calibrated: boolean;
  error: string | null;
  sampleId: string | null;
  distance: number;
  reading: Classification;
  history: Detection[];
  settings: DetectorSettings;
  autoDemo: boolean;
  setMode: (mode: DetectorMode) => void;
  setRunning: (running: boolean) => void;
  setTransmitting: (on: boolean) => void;
  setCalibrating: (on: boolean) => void;
  setCalibrated: (on: boolean) => void;
  setError: (error: string | null) => void;
  setSampleId: (id: string | null) => void;
  setDistance: (n: number) => void;
  setReading: (reading: Classification) => void;
  pushDetection: (d: Detection) => void;
  clearHistory: () => void;
  patchSettings: (partial: Partial<DetectorSettings>) => void;
  setAutoDemo: (on: boolean) => void;
};

export const useDetectorStore = create<DetectorStore>()((set) => ({
  mode: "sim",
  running: true,
  transmitting: false,
  calibrating: false,
  calibrated: true,
  error: null,
  sampleId: "iron-nail",
  distance: 0.22,
  reading: emptyClass,
  history: [],
  autoDemo: true,
  settings: {
    frequency: 4000,
    txGain: 0.22,
    threshold: 0.08,
    beep: true,
  },
  setMode: (mode) => set({ mode, error: null, calibrated: mode === "sim" }),
  setRunning: (running) => set({ running }),
  setTransmitting: (transmitting) => set({ transmitting }),
  setCalibrating: (calibrating) => set({ calibrating }),
  setCalibrated: (calibrated) => set({ calibrated }),
  setError: (error) => set({ error }),
  setSampleId: (sampleId) => set({ sampleId, autoDemo: false }),
  setDistance: (distance) => set({ distance, autoDemo: false }),
  setReading: (reading) => set({ reading }),
  pushDetection: (d) =>
    set((s) => ({
      history: [d, ...s.history].slice(0, 16),
    })),
  clearHistory: () => set({ history: [] }),
  patchSettings: (partial) =>
    set((s) => ({ settings: { ...s.settings, ...partial } })),
  setAutoDemo: (autoDemo) => set({ autoDemo }),
}));
