import { createFileRoute } from "@tanstack/react-router";
import { Instrument } from "@/components/detector/instrument";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Instrument />;
}
