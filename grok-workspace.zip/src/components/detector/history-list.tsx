import { useDetectorStore } from "@/lib/detector/store";
import { cn } from "@/lib/utils";

export function HistoryList() {
  const history = useDetectorStore((s) => s.history);
  const clearHistory = useDetectorStore((s) => s.clearHistory);

  return (
    <section className="rounded-xl bg-card p-4 shadow-border sm:p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-sm font-medium text-foreground">سجل الكشف</h2>
        {history.length > 0 ? (
          <button
            type="button"
            onClick={clearHistory}
            className="text-xs text-muted transition-colors duration-150 hover:text-foreground"
          >
            مسح
          </button>
        ) : null}
      </div>
      {history.length === 0 ? (
        <p className="text-sm leading-relaxed text-muted">
          تظهر هنا الأهداف بعد تجاوز العتبة. في المحاكاة اختر معدناً وقرّب الملف.
        </p>
      ) : (
        <ul className="space-y-1.5">
          {history.map((item) => (
            <li
              key={item.id}
              className="flex items-center justify-between gap-3 rounded-md bg-plot px-3 py-2"
            >
              <div className="min-w-0">
                <p className="truncate text-sm text-foreground">
                  {item.sampleName ?? item.label}
                </p>
                <p className="text-[11px] text-muted">
                  {new Date(item.at).toLocaleTimeString("ar", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  })}
                </p>
              </div>
              <div className="text-end">
                <p
                  className={cn(
                    "text-xs font-medium",
                    item.kind === "ferrous" ? "text-ferrous" : "text-nonferrous",
                  )}
                >
                  {item.label}
                </p>
                <p className="font-mono text-[11px] tabular-nums text-muted" dir="ltr">
                  {item.phaseDeg.toFixed(0)}° · VDI {item.vdi}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
