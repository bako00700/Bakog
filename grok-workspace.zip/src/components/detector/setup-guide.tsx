import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = [
  {
    title: "الإرسال 4 كيلوهرتز",
    body: "يولد التطبيق موجة جيبية ثابتة على مخرج الصوت. هذا هو الحقل الابتدائي. وصّل سماعة أو ملف إرسال على مخرج الأذن.",
  },
  {
    title: "الاستقبال",
    body: "مدخَل الميكروفون يلتقط الإشارة المرتدة — إمّا اقتراناً كهرومغناطيسياً من ملف استقبال، أو اقتراناً صوتياً/حثياً ضعيفاً من السماعة نفسها.",
  },
  {
    title: "قفل الطور",
    body: "يُضرب الاستقبال في جيبي وجيب تمام الإرسال (مضخم قفل) لاستخراج المركّبتين: R المقاومة (تيارات دوامية / موصلية) و X التفاعلية (نفاذية).",
  },
  {
    title: "معايرة الهواء",
    body: "اطرح متجه الهواء ليصبح الأصل هو «لا معدن». أي هدف يظهر كمتجه فرق طور. الحديد يميل نحو X، والنحاس والألومنيوم نحو R.",
  },
  {
    title: "ملف بحث بسيط",
    body: "50–120 لفة سلك نحاسي على إطار 10–20 سم، مقاومة 100Ω على مخرج السماعة. ملف أصغر إلى مدخل الميكروفون. عطّل إلغاء الصدى في النظام.",
  },
];

export function SetupGuide() {
  const [open, setOpen] = useState(false);

  return (
    <section className="rounded-xl bg-card p-4 shadow-border sm:p-5">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex h-11 w-full items-center justify-between gap-3 text-start"
        aria-expanded={open}
      >
        <span className="text-sm font-medium text-foreground">كيف يعمل الجهاز</span>
        <ChevronDown
          className={cn(
            "size-4 text-muted transition-transform duration-200 ease-out",
            open && "rotate-180",
          )}
        />
      </button>
      <div
        className={cn(
          "grid transition-[grid-template-rows,opacity] duration-200 ease-out",
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
        )}
      >
        <div className="overflow-hidden">
          <ol className="space-y-3 pb-1 pt-2">
            {STEPS.map((step, i) => (
              <li key={step.title} className="flex gap-3">
                <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-plot font-mono text-[11px] text-muted">
                  {i + 1}
                </span>
                <div>
                  <p className="text-sm font-medium text-foreground">{step.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted text-pretty">{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
