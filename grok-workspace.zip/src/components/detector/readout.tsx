import { Magnet, Waves } from "lucide-react";
import { cn } from "@/lib/utils";
import { useDetectorStore } from "@/lib/detector/store";

export function Readout() {
  const reading = useDetectorStore((s) => s.reading);
  const calibrated = useDetectorStore((s) => s.calibrated);
  const calibrating = useDetectorStore((s) => s.calibrating);
  const mode = useDetectorStore((s) => s.mode);
  const transmitting = useDetectorStore((s) => s.transmitting);

  const tone =
    reading.kind === "ferrous"
      ? "text-ferrous"
      : reading.kind === "nonferrous"
        ? "text-nonferrous"
        : reading.kind === "weak"
          ? "text-signal"
          : "text-muted";

  return (
    <section className="rounded-xl bg-card p-4 shadow-border sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted">التصنيف</p>
          <p className={cn("mt-1 text-3xl font-medium leading-none tracking-tight sm:text-4xl", tone)}>
            {reading.label}
          </p>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted text-pretty">
            {reading.detail}
          </p>
        </div>
        <StatusPills
          mode={mode}
          transmitting={transmitting}
          calibrated={calibrated}
          calibrating={calibrating}
        />
      </div>

      <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Metric label="فرق الطور" value={`${reading.phaseDeg >= 0 ? "+" : ""}${reading.phaseDeg.toFixed(1)}°`} />
        <Metric label="الشدة |Z|" value={reading.mag.toFixed(3)} />
        <Metric label="مؤشر التمييز" value={String(reading.vdi).padStart(2, "0")} hint="VDI" />
        <Metric
          label="الثقة"
          value={`${Math.round(reading.confidence * 100)}%`}
        />
      </dl>

      <div className="mt-4">
        <div className="mb-1.5 flex items-center justify-between text-xs text-muted">
          <span className="inline-flex items-center gap-1.5">
            <Waves className="size-3.5" />
            شدة الإشارة
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Magnet className="size-3.5" />
            {reading.kind === "ferrous" ? "نفاذية غالبة" : reading.kind === "nonferrous" ? "موصلية غالبة" : "متوازن"}
          </span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-border">
          <div
            className={cn(
              "h-full rounded-full transition-[width,background-color] duration-200 ease-out",
              reading.kind === "ferrous"
                ? "bg-ferrous"
                : reading.kind === "nonferrous"
                  ? "bg-nonferrous"
                  : "bg-signal",
            )}
            style={{ width: `${Math.min(100, reading.mag * 110)}%` }}
          />
        </div>
      </div>
    </section>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-lg bg-plot px-3 py-2.5">
      <dt className="text-[11px] text-muted">
        {label}
        {hint ? <span className="ms-1 font-mono opacity-70">{hint}</span> : null}
      </dt>
      <dd className="mt-1 font-mono text-lg font-medium tabular-nums tracking-tight text-foreground" dir="ltr">
        {value}
      </dd>
    </div>
  );
}

function StatusPills({
  mode,
  transmitting,
  calibrated,
  calibrating,
}: {
  mode: "sim" | "live";
  transmitting: boolean;
  calibrated: boolean;
  calibrating: boolean;
}) {
  return (
    <ul className="flex flex-wrap gap-1.5">
      <li className="rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted">
        {mode === "sim" ? "محاكاة" : "مسار حي"}
      </li>
      <li
        className={
          transmitting
            ? "rounded-full bg-signal/15 px-2.5 py-1 text-[11px] text-signal"
            : "rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted"
        }
      >
        {transmitting ? "إرسال 4 kHz" : "الإرسال متوقف"}
      </li>
      <li
        className={
          calibrated
            ? "rounded-full bg-plot px-2.5 py-1 text-[11px] text-foreground"
            : "rounded-full bg-plot px-2.5 py-1 text-[11px] text-muted"
        }
      >
        {calibrating ? "جارٍ المعايرة…" : calibrated ? "معايرة هواء جاهزة" : "بلا معايرة"}
      </li>
    </ul>
  );
}
