import { METAL_SAMPLES } from "@/lib/detector/samples";
import { useDetectorStore } from "@/lib/detector/store";
import { cn } from "@/lib/utils";

export function SamplesPanel() {
  const mode = useDetectorStore((s) => s.mode);
  const sampleId = useDetectorStore((s) => s.sampleId);
  const setSampleId = useDetectorStore((s) => s.setSampleId);
  const setDistance = useDetectorStore((s) => s.setDistance);

  return (
    <section className="rounded-xl bg-card p-4 shadow-border sm:p-5">
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-medium text-foreground">عينات المعادن</h2>
        <p className="text-xs text-muted">{mode === "sim" ? "اضغط لتقريب الملف" : "مرجع بصري فقط"}</p>
      </div>
      <ul className="grid grid-cols-2 gap-2">
        {METAL_SAMPLES.map((sample) => {
          const active = sampleId === sample.id;
          return (
            <li key={sample.id}>
              <button
                type="button"
                onClick={() => {
                  if (active) {
                    setSampleId(null);
                    setDistance(0.85);
                    return;
                  }
                  setSampleId(sample.id);
                  setDistance(0.16);
                }}
                className={cn(
                  "flex h-[72px] w-full flex-col items-start justify-center rounded-lg px-3 text-start transition-[background-color,box-shadow,color] duration-150",
                  active ? "bg-plot shadow-border-hover" : "bg-plot/60 shadow-border hover:shadow-border-hover",
                )}
              >
                <span className="flex w-full items-center justify-between gap-2">
                  <span className="text-sm font-medium text-foreground">{sample.name}</span>
                  <span
                    className={cn(
                      "font-mono text-[10px] tabular-nums",
                      sample.kind === "ferrous" ? "text-ferrous" : "text-nonferrous",
                    )}
                    dir="ltr"
                  >
                    {sample.latin}
                  </span>
                </span>
                <span className="mt-1 text-[11px] text-muted">
                  {sample.kind === "ferrous" ? "حديدي · طور مرتفع" : "غير حديدي · طور منخفض"}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <button
        type="button"
        onClick={() => {
          setSampleId(null);
          setDistance(0.9);
        }}
        className="mt-2 h-10 w-full rounded-lg text-sm text-muted transition-colors duration-150 hover:bg-plot hover:text-foreground"
      >
        هواء — بلا هدف
      </button>
    </section>
  );
}
