"use client";

import { useEffect } from "react";
import { Toaster } from "sonner";
import { detectorEngine } from "@/lib/detector/engine";
import { Controls } from "./controls";
import { HistoryList } from "./history-list";
import { IqPlot } from "./iq-plot";
import { PhaseDial } from "./phase-dial";
import { Readout } from "./readout";
import { SamplesPanel } from "./samples-panel";
import { SetupGuide } from "./setup-guide";
import { Waveform } from "./waveform";
import { useDetectorStore } from "@/lib/detector/store";

export function Instrument() {
  const frequency = useDetectorStore((s) => s.settings.frequency);
  const transmitting = useDetectorStore((s) => s.transmitting);

  useEffect(() => {
    detectorEngine.start();
    return () => {
      detectorEngine.stopLoop();
      detectorEngine.stopTransmit();
    };
  }, []);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <Toaster theme="dark" position="top-center" dir="rtl" richColors={false} />
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span
              className="relative flex size-9 items-center justify-center rounded-md bg-plot shadow-border"
              aria-hidden="true"
            >
              <span
                className={
                  transmitting
                    ? "size-2 rounded-full bg-signal motion-safe:animate-led"
                    : "size-2 rounded-full bg-muted"
                }
              />
            </span>
            <div>
              <p className="text-lg font-medium leading-none tracking-tight">حديدار</p>
              <p className="mt-1 text-xs text-muted">كاشف المعادن بفرق الطور الصوتي</p>
            </div>
          </div>
          <p className="font-mono text-sm tabular-nums text-signal" dir="ltr">
            {(frequency / 1000).toFixed(3)} kHz VLF
          </p>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-4 sm:px-6 sm:py-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="flex min-w-0 flex-col gap-4">
          <Readout />
          <IqPlot />
          <div className="grid gap-4 md:grid-cols-2">
            <PhaseDial />
            <Waveform />
          </div>
        </div>
        <aside className="flex flex-col gap-4 lg:sticky lg:top-4 lg:self-start">
          <Controls />
          <SamplesPanel />
          <HistoryList />
          <SetupGuide />
        </aside>
      </main>
    </div>
  );
}
