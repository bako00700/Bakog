import { useEffect, useRef } from "react";
import { detectorEngine } from "@/lib/detector/engine";
import { cssVar, fitCanvas } from "@/lib/detector/canvas";

export function Waveform() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;

    const draw = () => {
      const { width, height } = fitCanvas(canvas);
      const snap = detectorEngine.snapshot;
      const bg = cssVar("--color-plot", "#101411");
      const txColor = cssVar("--color-muted", "#8b9186");
      const rxColor = cssVar("--color-signal", "#7dba8a");
      const grid = cssVar("--color-border", "#2a2e2a");

      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = grid;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      ctx.lineTo(width, height / 2);
      ctx.stroke();

      const paint = (data: Float32Array, color: string, alpha: number) => {
        ctx.beginPath();
        const n = data.length;
        for (let i = 0; i < n; i++) {
          const x = (i / (n - 1)) * width;
          const y = height / 2 - data[i] * height * 0.38;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = color;
        ctx.globalAlpha = alpha;
        ctx.lineWidth = Math.max(1.25, width / 360);
        ctx.stroke();
        ctx.globalAlpha = 1;
      };

      paint(snap.tx, txColor, 0.55);
      paint(snap.rx, rxColor, 0.95);
      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="flex min-h-[148px] flex-col rounded-xl bg-card p-3 shadow-border sm:p-4">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-medium text-foreground">الإرسال والاستقبال</h2>
        <p className="text-xs text-muted">
          <span className="text-muted">إرسال</span>
          <span className="mx-2 text-signal">استقبال</span>
        </p>
      </div>
      <canvas ref={ref} className="h-[112px] w-full rounded-lg sm:h-[128px]" />
    </div>
  );
}
