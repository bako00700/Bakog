import type { ReactNode } from "react";
import { Mic, Radio, Square, Waves } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { detectorEngine } from "@/lib/detector/engine";
import { useDetectorStore } from "@/lib/detector/store";
import { cn } from "@/lib/utils";

export function Controls() {
  const mode = useDetectorStore((s) => s.mode);
  const transmitting = useDetectorStore((s) => s.transmitting);
  const calibrating = useDetectorStore((s) => s.calibrating);
  const settings = useDetectorStore((s) => s.settings);
  const distance = useDetectorStore((s) => s.distance);
  const error = useDetectorStore((s) => s.error);
  const patchSettings = useDetectorStore((s) => s.patchSettings);
  const setMode = useDetectorStore((s) => s.setMode);
  const setDistance = useDetectorStore((s) => s.setDistance);

  async function toggleTx() {
    if (transmitting) {
      detectorEngine.stopTransmit();
      return;
    }
    await detectorEngine.startTransmit();
  }

  function calibrate() {
    detectorEngine.beginCalibration(40);
    toast.success("عُيّنت نقطة الصفر على الهواء");
  }

  async function chooseMode(next: "sim" | "live") {
    if (next === mode) return;
    if (transmitting) detectorEngine.stopTransmit();
    setMode(next);
    if (next === "live") {
      await detectorEngine.startTransmit();
    }
  }

  return (
    <section className="rounded-xl bg-card p-4 shadow-border sm:p-5">
      <div className="grid grid-cols-2 gap-1 rounded-lg bg-plot p-1">
        <button
          type="button"
          onClick={() => void chooseMode("sim")}
          className={cn(
            "flex h-10 items-center justify-center gap-1.5 rounded-md text-sm font-medium transition-[background-color,color] duration-150",
            mode === "sim" ? "bg-card text-foreground shadow-border" : "text-muted hover:text-foreground",
          )}
        >
          <Waves className="size-3.5" />
          محاكاة
        </button>
        <button
          type="button"
          onClick={() => void chooseMode("live")}
          className={cn(
            "flex h-10 items-center justify-center gap-1.5 rounded-md text-sm font-medium transition-[background-color,color] duration-150",
            mode === "live" ? "bg-card text-foreground shadow-border" : "text-muted hover:text-foreground",
          )}
        >
          <Mic className="size-3.5" />
          مسار حي
        </button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button
          variant={transmitting ? "secondary" : "signal"}
          className="h-12"
          onClick={() => void toggleTx()}
        >
          {transmitting ? <Square className="size-3.5 fill-current" /> : <Radio className="size-3.5" />}
          {transmitting ? "إيقاف الإرسال" : "تشغيل الإرسال"}
        </Button>
        <Button variant="outline" className="h-12" onClick={calibrate} disabled={calibrating}>
          {calibrating ? "معايرة…" : "معايرة الهواء"}
        </Button>
      </div>

      {error ? <p className="mt-3 text-sm text-ferrous">{error}</p> : null}

      <div className="mt-5 space-y-4">
        <Field
          label="تردد الإرسال"
          value={`${(settings.frequency / 1000).toFixed(2)} kHz`}
        >
          <Slider
            min={2000}
            max={8000}
            step={50}
            value={[settings.frequency]}
            onValueChange={([v]) => patchSettings({ frequency: v ?? 4000 })}
            dir="ltr"
          />
        </Field>
        <Field label="سعة الإرسال" value={`${Math.round(settings.txGain * 100)}%`}>
          <Slider
            min={0.04}
            max={0.7}
            step={0.01}
            value={[settings.txGain]}
            onValueChange={([v]) => patchSettings({ txGain: v ?? 0.22 })}
            dir="ltr"
          />
        </Field>
        <Field label="عتبة الكشف" value={settings.threshold.toFixed(3)}>
          <Slider
            min={0.02}
            max={0.28}
            step={0.005}
            value={[settings.threshold]}
            onValueChange={([v]) => patchSettings({ threshold: v ?? 0.08 })}
            dir="ltr"
          />
        </Field>
        {mode === "sim" ? (
          <Field label="مسافة الملف" value={`${Math.round(distance * 100)} سم`}>
            <Slider
              min={0.02}
              max={0.95}
              step={0.01}
              value={[distance]}
              onValueChange={([v]) => setDistance(v ?? 0.22)}
              dir="ltr"
            />
          </Field>
        ) : null}
        <div className="flex items-center justify-between gap-3 pt-1">
          <label htmlFor="beep" className="text-sm text-foreground">
            نغمة التمييز
          </label>
          <Switch
            id="beep"
            dir="ltr"
            checked={settings.beep}
            onCheckedChange={(beep) => patchSettings({ beep })}
          />
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  children,
}: {
  label: string;
  value: string;
  children: ReactNode;
}) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <span className="text-sm text-foreground">{label}</span>
        <span className="font-mono text-xs tabular-nums text-muted" dir="ltr">
          {value}
        </span>
      </div>
      {children}
    </div>
  );
}
