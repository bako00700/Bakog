import { useDetectorStore } from "@/lib/detector/store";

export function PhaseDial() {
  const reading = useDetectorStore((s) => s.reading);
  const angle = reading.phaseDeg;
  const needle = -angle;

  return (
    <div className="flex min-h-[148px] flex-col rounded-xl bg-card p-3 shadow-border sm:p-4">
      <h2 className="mb-2 text-sm font-medium text-foreground">فرق الطور</h2>
      <div className="flex flex-1 items-center gap-4">
        <svg viewBox="0 0 160 160" className="size-[112px] shrink-0 sm:size-[128px]">
          <circle cx="80" cy="80" r="62" fill="var(--color-plot)" />
          <circle
            cx="80"
            cy="80"
            r="62"
            fill="none"
            stroke="var(--color-border)"
            strokeWidth="1"
          />
          <path
            d="M80 80 L142 80 A62 62 0 0 0 80 18 Z"
            fill="var(--color-nonferrous)"
            opacity="0.18"
          />
          <path
            d="M80 80 L80 18 A62 62 0 0 0 18 80 Z"
            fill="var(--color-ferrous)"
            opacity="0.18"
          />
          {[0, 45, 90, 135, 180, -45, -90, -135].map((deg) => {
            const rad = (deg * Math.PI) / 180;
            const x1 = 80 + Math.cos(rad) * 54;
            const y1 = 80 - Math.sin(rad) * 54;
            const x2 = 80 + Math.cos(rad) * 62;
            const y2 = 80 - Math.sin(rad) * 62;
            return (
              <line
                key={deg}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke="var(--color-muted)"
                strokeWidth="1.2"
              />
            );
          })}
          <g
            style={{
              transform: `rotate(${needle}deg)`,
              transformOrigin: "80px 80px",
              transition: "transform 120ms cubic-bezier(0.22, 1, 0.36, 1)",
            }}
          >
            <line
              x1="80"
              y1="80"
              x2="132"
              y2="80"
              stroke="var(--color-signal)"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
            <circle cx="80" cy="80" r="4" fill="var(--color-foreground)" />
          </g>
          <text x="132" y="76" fill="var(--color-muted)" fontSize="8">
            0°
          </text>
          <text x="72" y="24" fill="var(--color-muted)" fontSize="8">
            90°
          </text>
        </svg>
        <div className="min-w-0">
          <p
            className="font-mono text-3xl font-medium tabular-nums leading-none tracking-tight text-foreground"
            dir="ltr"
          >
            {angle >= 0 ? "+" : ""}
            {angle.toFixed(1)}°
          </p>
          <p className="mt-2 text-xs leading-relaxed text-muted">
            الزاوية بين إشارة الإرسال 4 كيلوهرتز والإشارة المرتدة بعد طرح معايرة الهواء.
          </p>
        </div>
      </div>
    </div>
  );
}
