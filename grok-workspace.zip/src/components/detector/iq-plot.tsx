import { useEffect, useRef } from "react";
import { detectorEngine } from "@/lib/detector/engine";
import { cssVar, fitCanvas } from "@/lib/detector/canvas";

export function IqPlot() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let raf = 0;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = () => {
      const { width, height } = fitCanvas(canvas);
      const snap = detectorEngine.snapshot;
      const bg = cssVar("--color-plot", "#101411");
      const grid = cssVar("--color-border", "#2a2e2a");
      const muted = cssVar("--color-muted", "#8b9186");
      const ferrous = cssVar("--color-ferrous", "#c4785a");
      const nonferrous = cssVar("--color-nonferrous", "#7a9eb0");
      const signal = cssVar("--color-signal", "#7dba8a");
      const fg = cssVar("--color-foreground", "#eceee9");

      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const scale = Math.min(width, height) * 0.38;

      ctx.save();
      ctx.translate(cx, cy);

      ctx.globalAlpha = 0.14;
      ctx.fillStyle = ferrous;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, scale, -Math.PI * 0.72, -Math.PI * 0.28);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = nonferrous;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, scale, -Math.PI * 0.22, Math.PI * 0.22);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1;

      ctx.strokeStyle = grid;
      ctx.lineWidth = Math.max(1, width / 420);
      for (const r of [0.33, 0.66, 1]) {
        ctx.beginPath();
        ctx.arc(0, 0, scale * r, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(-scale * 1.08, 0);
      ctx.lineTo(scale * 1.08, 0);
      ctx.moveTo(0, -scale * 1.08);
      ctx.lineTo(0, scale * 1.08);
      ctx.stroke();

      ctx.fillStyle = muted;
      ctx.font = `${Math.round(width * 0.032)}px "IBM Plex Sans Arabic", sans-serif`;
      ctx.textAlign = "center";
      ctx.fillText("X نفاذية", 0, -scale * 1.14);
      ctx.textAlign = "left";
      ctx.fillText("R موصلية", scale * 0.72, 16);

      const trail = snap.trail;
      if (trail.length > 1) {
        ctx.beginPath();
        for (let i = 0; i < trail.length; i++) {
          const p = trail[i];
          const x = p.i * scale * 1.05;
          const y = -p.q * scale * 1.05;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = signal;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = Math.max(1.2, width / 280);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      const vx = snap.i * scale * 1.05;
      const vy = -snap.q * scale * 1.05;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(vx, vy);
      ctx.strokeStyle = snap.kind === "ferrous" ? ferrous : snap.kind === "nonferrous" ? nonferrous : signal;
      ctx.lineWidth = Math.max(2, width / 200);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(vx, vy, Math.max(4, width / 90), 0, Math.PI * 2);
      ctx.fillStyle = fg;
      ctx.fill();

      ctx.restore();
      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="flex h-full min-h-[240px] flex-col rounded-xl bg-card p-3 shadow-border sm:min-h-[280px] sm:p-4">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-medium text-foreground">مستوى الطور I/Q</h2>
        <p className="text-xs text-muted">محور R موصلية · محور X نفاذية</p>
      </div>
      <canvas ref={ref} className="h-full min-h-[200px] w-full flex-1 rounded-lg" />
    </div>
  );
}
